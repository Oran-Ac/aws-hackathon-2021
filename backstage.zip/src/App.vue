<template>
  <div id="app">
    <!-- 自动注入路由网页 -->
    <router-view />
  </div>
</template>

<script>
export default {
  name: "app",
  components: {},
};
</script>

<style>
@import "./assets/style.css";
</style>
